1.Include this sound to your basic fg Sound folder,
2.delete "wave.wav" there, 
3.rename your "newwave.wav" into "wave.wav" 
4. and u have this oceansound in all your seaplanes !

(if its to large for u, cut it or record ur own)

Licence is by Atlantic Ocean
this sound is recorded by my self in summer 2011 at Northsea.

T .Henkel